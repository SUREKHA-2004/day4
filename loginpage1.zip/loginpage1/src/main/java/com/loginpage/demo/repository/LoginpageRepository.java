package com.loginpage.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.loginpage.demo.model.LoginpageModel;

@Repository
public interface LoginpageRepository extends JpaRepository <LoginpageModel,Integer>{
	LoginpageModel findByUsername(String username);

}
